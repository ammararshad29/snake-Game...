Versions:
	0.1:
		- set up basic structure

	1.0: <- current release
		- stable mostly
		- fully functional snake game
		- eat food to grow snake
	1.1:
		- optimise how snake is refrshed in display
		- improve AI
		- improve user experience with restarting games
		- more customisation with starting new games